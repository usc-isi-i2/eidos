<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT name,ODI_debut,ODI_latest,ODI_batting_matches,ODI_batting_innings,ODI_batting_not_outs,ODI_batting_runs_scored,ODI_batting_highest,ODI_batting_average,ODI_batting_strike_rate,ODI_batting_hundreds,ODI_batting_fifties,ODI_fielding_catches,ODI_fielding_stumpings,ODI_bowling_balls,ODI_bowling_maidens,ODI_bowling_runs_given,ODI_bowling_wickets,ODI_bowling_average,ODI_bowling_best,ODI_bowling_strike_rate,ODI_bowling_runs_per_over
 FROM imap.cricinfo c where (name = '$attr0') and (ODI_debut <> '')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>