<?php

// converts distance from kilometres to miles

$miles = $_GET['attr0'];

$km = round( $miles * 1.609344 , 3);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>miles</td>\n";
echo "\t\t<td>kilometers</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$miles</td>\n";
echo "\t\t<td>$km</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 