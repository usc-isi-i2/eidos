<?php

	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql =  "SELECT code,name,capital FROM miscellaneous.usstates WHERE (code='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>