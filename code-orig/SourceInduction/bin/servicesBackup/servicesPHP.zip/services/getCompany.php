<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT t0.ticker, t0.company, t0.industry, t0.exchange FROM miscellaneous.companies2006 t0 WHERE (t0.ticker='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>