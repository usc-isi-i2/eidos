<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT name,date_of_birth,place_of_birth,date_of_death,place_of_death,major_teams,known_as,batting_style,bowling_style
 FROM imap.cricinfo c where (name = '$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>