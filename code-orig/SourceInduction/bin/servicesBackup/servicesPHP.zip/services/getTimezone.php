<?php

	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql =  "SELECT t0.state_abbrev AS state,t1.commonAbbr AS timezone,substr(t1.zone,4) as timeoffset,NOT(t1.noDST) as daylightSavings FROM miscellaneous.statecodes t0, miscellaneous.timezones t1 WHERE (t0.state_name = t1.region) AND (t0.state_abbrev='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>