<?php

require('GeoCalc.class.php');

$lat1 = $_GET['attr0'];
$lon1 = $_GET['attr1'];

$lat2 = $_GET['attr2'];
$lon2 = $_GET['attr3'];

 $oGC = new GeoCalc();

$dist = $oGC->EllipsoidDistance($lat1,$lon1,$lat2,$lon2);
//(3958*3.1415926*sqrt(($lat2-$lat1)*($lat2-$lat1) + cos($lat2/57.29578)*cos($lat1/57.29578)*($lon2-$lon1)*($lon2-$lon1))/180);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>latitude1</td>\n";
echo "\t\t<td>longitude1</td>\n";
echo "\t\t<td>latitude2</td>\n";
echo "\t\t<td>longitude2</td>\n";
echo "\t\t<td>distance</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$lat1</td>\n";
echo "\t\t<td>$lon1</td>\n";
echo "\t\t<td>$lat2</td>\n";
echo "\t\t<td>$lon2</td>\n";
echo "\t\t<td>$dist</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 