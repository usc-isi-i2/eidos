<?php

	require('Query.class.php');
	
	$attr0 = substr($_GET['attr0'],0,5);
	$sql = "SELECT t0.zipcode AS zip, t0.postofficename AS city, t1.state_abbrev AS state FROM uscensusbureau.zipnov99 t0, miscellaneous.statecodes t1 WHERE (t0.fips_state = t1.fips_code) AND (t0.zipcode='$attr0')";

	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>