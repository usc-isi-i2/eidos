<?php

	// Check for authorized user:
	if ($_GET['auth']!="taipei101") die ('Incorrect Authentication Header!');
	
	require('Query.class.php');
	
	$sql = trim($_GET['sql']);
	//echo $sql;
		
	// allow only select queries:
	if (substr( strtolower($sql), 0, 7) === "select ") {
	
		$query = new Query();
		$query->run($sql);
		
	}	
	else {
		echo "only select queries are allowed!";
	}
?>