<?php

	require('Query.class.php');
	
	$attr0 = substr($_GET['attr0'],0,5);
	$sql = "SELECT zipcode,latitude,longitude FROM uscensusbureau.zipnov99 WHERE zipcode='$attr0'";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>