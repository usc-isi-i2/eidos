<?php

// converts dateTime into timestamp

// if no timezone is given GMT is assumed:
date_default_timezone_set("GMT"); 

$datetime = $_GET['attr0'];

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>datetime</td>\n";
echo "\t\t<td>timestamp</td>\n";
echo "\t</tr>\n";

// data
if ($timestamp = strtotime($datetime)) {
 echo "\t<tr>\n";
 echo "\t\t<td>$datetime</td>\n";
 echo "\t\t<td>$timestamp</td>\n";
 echo "\t</tr>\n";
}

echo "</table>\n";

?> 