<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT playing_for,name,Initials,Date_of_birth,Player_type,Batting_style,Bowling_style FROM imap.cricbase c where (playing_for = '$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>