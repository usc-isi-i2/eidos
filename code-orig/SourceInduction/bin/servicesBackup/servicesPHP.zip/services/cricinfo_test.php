<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT name,test_debut,test_latest,test_batting_matches,test_batting_innings,test_batting_not_outs,test_batting_runs_scored,test_batting_highest,test_batting_average,test_batting_strike_rate,test_batting_hundreds,test_batting_fifties,test_fielding_catches,test_fielding_stumpings,test_bowling_balls,test_bowling_maidens,test_bowling_runs_given,test_bowling_wickets,test_bowling_average,test_bowling_best,test_bowling_strike_rate,test_bowling_runs_per_over
 FROM imap.cricinfo c where (name = '$attr0') and (test_debut <> '')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>