<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT t0.code, t0.name, t0.country FROM miscellaneous.currencies t0 WHERE (t0.code='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>