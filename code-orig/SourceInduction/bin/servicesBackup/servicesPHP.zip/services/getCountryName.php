<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT code2,name FROM miscellaneous.countries WHERE (code2='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>