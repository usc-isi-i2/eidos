<?php

class Query {
	
		// Perform query
	function run($sql) {
		
		// Connect to db server
		$link = mysql_connect('localhost', 'root', 'taipei')
			or die('Could not connect: ' . mysql_error());
		
		// Select db
		mysql_select_db('db1') or die('Could not select database');
		
		$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
		
		// Print results in XML
		/*echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\" ?>\n";*/
		echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n"; 
		echo "<table border='0' cellspacing='5'>\n";
		
		// first print column names
		$width = mysql_num_fields($result);
		echo "\t<tr>\n";
		for ($i=0; $i<$width; $i++) {
			$field = mysql_field_name($result,$i);
			echo "\t\t<td>$field</td>\n";
		}
		echo "\t</tr>\n";
		
		// then the data
		while ($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "\t<tr>\n";
			foreach ($line as $col_value) {
				//echo "\t\t<td>", htmlentities(utf8_encode($col_value)), "</td>\n";
				echo "\t\t<td>", htmlentities($col_value), "</td>\n";
			}
			echo "\t</tr>\n";
		}
		echo "</table>\n";
		
		// free the resultset
		mysql_free_result($result);
		
		// close connection
		mysql_close($link);
	}
	
	
	// Perform query
	function returnXML($sql) {
		
		// Connect to db server
		$link = mysql_connect('localhost', 'root', 'taipei')
			or die('Could not connect: ' . mysql_error());
		
		// Select db
		mysql_select_db('db1') or die('Could not select database');
		
		$result = mysql_query($sql) or die('Query failed: ' . mysql_error());
		$width = mysql_num_fields($result);
		
		// generate XML
		$xmlDoc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n"; 
		$xmlDoc .= "<results>\n";
		while ($row = mysql_fetch_array($result, MYSQL_NUM)) {
			$xmlDoc .= "\t<row>\n";
			for ($i=0; $i<$width; $i++) {
				$tag = mysql_field_name($result,$i);
				$val = htmlentities($row[$i]); 
				$xmlDoc .= "\t\t<$tag>$val</$tag>\n";
			}
			$xmlDoc .= "\t</row>\n";
		}
		$xmlDoc .= "</results>\n";
		
		// free the resultset
		mysql_free_result($result);
		// close connection
		mysql_close($link);
		
		header("Content-type: text/xml");
		echo $xmlDoc;
	}

}
	
?>