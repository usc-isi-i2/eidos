<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT t0.country, t0.name, t0.code FROM miscellaneous.currencies t0 WHERE (t0.country='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>