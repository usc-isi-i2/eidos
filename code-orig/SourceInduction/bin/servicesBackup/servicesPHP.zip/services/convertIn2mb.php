<?php


$in = $_GET['attr0'];

$mb = round ( $in * 33.8639 , 2);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>inchesOfMercury</td>\n";
echo "\t\t<td>millibars</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$in</td>\n";
echo "\t\t<td>$mb</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 