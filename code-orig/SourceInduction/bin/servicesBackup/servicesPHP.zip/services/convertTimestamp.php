<?php

// converts dateTime into timestamp, date, time, timezone

$timestamp = $_GET['attr0'];

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>timestamp</td>\n";
echo "\t\t<td>datetime</td>\n";
echo "\t\t<td>date</td>\n";
echo "\t\t<td>time</td>\n";
echo "\t\t<td>timezone</td>\n";
echo "\t</tr>\n";

// data
$datetime = date("D, j M Y, g:i A T",$timestamp);
$date = date("D, j M Y",$timestamp);
$time = date("g:i A",$timestamp);
$timezone = date("T",$timestamp);
echo "\t<tr>\n";
echo "\t\t<td>$timestamp</td>\n";
echo "\t\t<td>$datetime</td>\n";
echo "\t\t<td>$date</td>\n";
echo "\t\t<td>$time</td>\n";
echo "\t\t<td>$timezone</td>\n";
echo "\t</tr>\n";

echo "</table>\n";

?> 