<?php

	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	//$sql = "SELECT * FROM miscellaneous.airlines a WHERE (a.code='$attr0')";
	$sql = "SELECT a.code,a.airline FROM miscellaneous.airlines a WHERE (a.code='$attr0')";

	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>