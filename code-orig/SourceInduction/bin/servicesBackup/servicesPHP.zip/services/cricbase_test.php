<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT playing_for,name,Test_caps,First_test_cap,Last_test_cap,test_matches,test_innings,test_runs_scored,test_batting_average,test_fifties,test_hundreds,test_highest_score,test_balls,test_runs_given,test_wickets,test_bowling_average,test_bowling_strike_rate,test_runs_per_over,test_five_wickets,test_ten_wickets,test_best_performance
 FROM imap.cricbase c where (playing_for = '$attr0') and (First_test_cap <> '')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>