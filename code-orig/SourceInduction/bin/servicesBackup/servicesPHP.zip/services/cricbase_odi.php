<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT playing_for,name,One_day_caps,First_one_day_cap,Last_one_day_cap,ODI_matches,ODI_innings,ODI_runs_scored,ODI_batting_average,ODI_fifties,ODI_hundreds,ODI_highest_score,ODI_balls,ODI_runs_given,ODI_wickets,ODI_bowling_average,ODI_bowling_strike_rate,ODI_runs_per_over,ODI_five_wickets,ODI_ten_wickets,ODI_best_performance
 FROM imap.cricbase c where (playing_for = '$attr0') and (First_one_day_cap <> '')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>