<?php

	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT iata,name,latitude,longitude FROM miscellaneous.airportcoordinates a WHERE (a.iata='$attr0')";

	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>