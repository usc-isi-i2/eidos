<?php

	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$attr1 = $_GET['attr1'];
	$sql = "SELECT make,year,model,trim FROM miscellaneous.cars c WHERE (c.make='$attr0') AND (c.year='$attr1')";

	//echo $sql;
	
	$query = new Query();
	$query->run($sql);

?>