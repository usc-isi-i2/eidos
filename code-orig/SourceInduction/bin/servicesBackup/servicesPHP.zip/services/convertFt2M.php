<?php

// converts distance from meters to feet

$feet = $_GET['attr0'];

$meters = round( $feet / 3.2808399 , 3);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>feet</td>\n";
echo "\t\t<td>meters</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$feet</td>\n";
echo "\t\t<td>$meters</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 