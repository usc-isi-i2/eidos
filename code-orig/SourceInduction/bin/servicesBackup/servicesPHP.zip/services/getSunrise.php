<?php

// NOTE: this service computes sunrise for a given lat/long for today 
//  - it could be made to take an extra date/time input and calculate sunrise for a partiucular day in the past/future....

$latitude  = $_GET['attr0'];
$longitude = $_GET['attr1'];
$timestamp = date_sunrise(time(), SUNFUNCS_RET_TIMESTAMP, $latitude, $longitude);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>latitude</td>\n";
echo "\t\t<td>longitude</td>\n";
echo "\t\t<td>timestamp</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$latitude</td>\n";
echo "\t\t<td>$longitude</td>\n";
echo "\t\t<td>$timestamp</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 