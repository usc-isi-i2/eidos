<?php

// converts temperature from fahrenheit to  celsius

$fahrenheit = $_GET['attr0'];

$celsius = round ( ($fahrenheit - 32) / 1.8 , 2);

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>fahrenheit</td>\n";
echo "\t\t<td>celsius</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$fahrenheit</td>\n";
echo "\t\t<td>$celsius</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 