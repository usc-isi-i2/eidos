<?php

require('GeoCalc.class.php');

$latDMS = trim($_GET['attr0']);
$lonDMS = trim($_GET['attr1']);

$latArray = explode(".",$latDMS);
$lonArray = explode(".",$lonDMS);

$latD = $latArray[0];
$latM = $latArray[1];
$latS = $latArray[2];
$latDec = round($latD + $latM/60 + $latS/3600, 5);
if (stripos($latS,"S")) {$latDec *= -1;}

$lonD = $lonArray[0];
$lonM = $lonArray[1];
$lonS = $lonArray[2];
$lonDec = round($lonD + $lonM/60 + $lonS/3600, 5);
if (stripos($lonS,"W")) {$lonDec *= -1;}

// Printing results in HTML table
echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\" ?>\n";
echo "<table border='0' cellspacing='5'>\n";
// metadata
echo "\t<tr>\n";
echo "\t\t<td>latitudeDMS</td>\n";
echo "\t\t<td>longitudeDMS</td>\n";
echo "\t\t<td>latitudeDec</td>\n";
echo "\t\t<td>longitudeDec</td>\n";
echo "\t</tr>\n";
// data
echo "\t<tr>\n";
echo "\t\t<td>$latDMS</td>\n";
echo "\t\t<td>$lonDMS</td>\n";
echo "\t\t<td>$latDec</td>\n";
echo "\t\t<td>$lonDec</td>\n";
echo "\t</tr>\n";
echo "</table>\n";

?> 