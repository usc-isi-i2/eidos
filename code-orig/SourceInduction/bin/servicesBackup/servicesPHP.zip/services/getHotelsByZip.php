<?php
	
	require('Query.class.php');
	
	$attr0 = $_GET['attr0'];
	$sql = "SELECT t0.zip,t0.name,t0.address,t0.city,t0.state,t0.rooms FROM miscellaneous.ushotels t0 WHERE (t0.zip='$attr0')";
	
	//echo $sql;
	
	$query = new Query();
	$query->run($sql);
	
?>